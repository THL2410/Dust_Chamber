import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { DesignProjects } from './entities/DesignProjects';
import { DesignInputs } from './entities/DesignInputs';
import { DesignResults } from './entities/DesignResults';
import { CreateCalculationDto } from './dto/create-calculation.dto';

@Injectable()
export class CalculationsService {
  constructor(
    @InjectRepository(DesignProjects)
    private projectRepo: Repository<DesignProjects>,
    @InjectRepository(DesignInputs)
    private inputRepo: Repository<DesignInputs>,
    @InjectRepository(DesignResults)
    private resultRepo: Repository<DesignResults>,
  ) {}

  async calculateAndSave(userId: number, dto: CreateCalculationDto) {
    // 1. Tạo và lưu project mới gắn với user
    const project = this.projectRepo.create({
      name: dto.name || 'Phương án buồng lắng bụi',
      userId: userId,
      mode: 'DESIGN',
    });
    const savedProject = await this.projectRepo.save(project);

    // 2. Lưu thông số đầu vào (DesignInputs)
    const input = this.inputRepo.create({
      projectId: savedProject.id,
      flowRateM3H: dto.flowRateM3H,
      temperatureC: dto.temperatureC,
      dustDensityKgM3: dto.dustDensityKgM3,
      dustConcentrationGM3: dto.dustConcentrationGM3,
      chamberHeightM: dto.chamberHeightM,
      chamberLengthM: dto.chamberLengthM,
      gasVelocityMS: dto.gasVelocityMS || 0.18,
    });
    await this.inputRepo.save(input);

    // 3. Thực hiện thuật toán tính toán buồng lắng bụi mẫu
    const Q = dto.flowRateM3H / 3600;
    const v = dto.gasVelocityMS || 0.18;
    const H = dto.chamberHeightM || 1.5;
    
    const S = v > 0 ? Q / v : 0;
    const calculatedHM = H;
    const calculatedLM = dto.chamberLengthM || 5.0;
    const calculatedBM = H > 0 ? S / H : 1.0;

    // 4. Lưu kết quả tính toán (DesignResults)
    const result = this.resultRepo.create({
      projectId: savedProject.id,
      hM: calculatedHM,
      lM: calculatedLM,
      bM: calculatedBM,
      etaTotalPercent: 85.5, 
      cbOutMgM3: 15.2,
      fanPowerKw: 2.4,
    });
    await this.resultRepo.save(result);

    return {
      message: 'Tính toán và lưu phương án thành công!',
      projectId: savedProject.id,
      input,
      result,
    };
  }

  // Lấy toàn bộ lịch sử theo User ID
  async findAllByUser(userId: number) {
    return await this.projectRepo.find({
      where: { userId },
      relations: {
        designInputs: true,   // Khớp với tên trong entity
        designResults: true,  // Khớp với tên trong entity
      },
      order: { createdAt: 'DESC' },
    });
  }

  // Xem chi tiết 1 phương án
  async findOne(id: number) {
    const project = await this.projectRepo.findOne({
      where: { id },
      relations: {
        designInputs: true,   // Khớp với tên trong entity
        designResults: true,  // Khớp với tên trong entity
      },
    });
    if (!project) {
      throw new NotFoundException(`Không tìm thấy phương án với ID ${id}`);
    }
    return project;
  }

  // Xóa phương án tính toán
  async remove(id: number) {
    const project = await this.findOne(id);
    await this.projectRepo.remove(project);
    return { message: `Đã xóa phương án có ID ${id} thành công` };
  }
}