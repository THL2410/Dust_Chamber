import { IsNotEmpty, IsNumber, IsOptional, IsString } from 'class-validator';

export class CreateCalculationDto {
  @IsString()
  @IsOptional()
  name?: string; // Tên phương án thiết kế

  @IsNumber()
  @IsNotEmpty()
  flowRateM3H!: number; // Lưu lượng khí (m3/h)

  @IsNumber()
  @IsNotEmpty()
  temperatureC!: number; // Nhiệt độ khí (°C)

  @IsNumber()
  @IsOptional()
  dustConcentrationGM3?: number; // Nồng độ bụi vào (g/m3)

  @IsNumber()
  @IsNotEmpty()
  dustDensityKgM3!: number; // Khối lượng riêng của bụi (kg/m3)

  @IsNumber()
  @IsOptional()
  chamberHeightM?: number; // Chiều cao buồng (m)

  @IsNumber()
  @IsOptional()
  chamberLengthM?: number; // Chiều dài buồng (m)

  @IsNumber()
  @IsOptional()
  gasVelocityMS?: number; // Tốc độ dòng khí (m/s)
}